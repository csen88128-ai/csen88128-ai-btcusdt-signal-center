from datetime import datetime, timezone
import pandas as pd

from src_core_signals.closed_kline import filter_closed_only
from src_core_signals.lifecycle import evaluate_lifecycle


def test_closed_only_filters_open_candle():
    df = pd.DataFrame({"dt": ["2026-07-10T00:00:00Z", "2026-07-10T00:05:00Z"], "close": [1, 2]})
    out = filter_closed_only(df, "5m", datetime(2026, 7, 10, 0, 6, tzinfo=timezone.utc))
    assert len(out) == 1
    assert out["close"].iloc[0] == 1


def test_lifecycle_downgrade_when_neutralized():
    res = evaluate_lifecycle("short", "strong", "neutral", "weak", {"4h":"neutral","1h":"long"})
    assert res.status == "downgraded"


def test_lifecycle_invalidates_on_4h_1h_opposite():
    res = evaluate_lifecycle("short", "strong", "long", "moderate", {"4h":"long","1h":"long"})
    assert res.status == "invalidated"
