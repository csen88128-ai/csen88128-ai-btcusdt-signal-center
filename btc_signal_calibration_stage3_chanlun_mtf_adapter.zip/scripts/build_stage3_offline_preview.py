import os, zipfile, glob, json, math, shutil
from pathlib import Path
from dataclasses import asdict
from datetime import datetime, timezone
import pandas as pd
import numpy as np

BASE=Path('/mnt/data')
OUT=BASE/'btc_signal_calibration_stage3_chanlun_mtf'
if OUT.exists(): shutil.rmtree(OUT)
for p in ['data_feature_store','reports','src_core_signals','tests','scripts','snapshots']:
    (OUT/p).mkdir(parents=True,exist_ok=True)

ZIP_MAP={
 '5m':'btc-kline-5m-2y.zip','15m':'btc-kline-15m-2y.zip','30m':'btc-kline-30m-2y.zip','1h':'btc-kline-1h-2y.zip','4h':'btc-kline-4h-2y.zip','1d':'btc-kline-1d-4y.zip'
}
mins={'5m':5,'15m':15,'30m':30,'1h':60,'4h':240,'1d':1440}

def load_csv_from_zip(zip_name):
    zpath=BASE/zip_name
    with zipfile.ZipFile(zpath) as z:
        csvs=[n for n in z.namelist() if n.endswith('.csv')]
        if not csvs: raise ValueError(f'No CSV in {zip_name}')
        with z.open(csvs[0]) as f:
            df=pd.read_csv(f)
    return df

def standardize(df, interval):
    colmap={
        'timestamp':'ts','t':'ts',
        'datetime':'dt','dt':'dt',
        'open':'open','o':'open',
        'high':'high','h':'high',
        'low':'low','l':'low',
        'close':'close','c':'close',
        'vol_quote':'volume_quote','vq':'volume_quote','volume_quote':'volume_quote',
        'vol_base':'volume_base','vb':'volume_base','volume_base':'volume_base'
    }
    df=df.rename(columns={c:colmap.get(c,c) for c in df.columns}).copy()
    need=['ts','dt','open','high','low','close','volume_quote']
    miss=[c for c in need if c not in df.columns]
    if miss: raise ValueError(f'{interval} missing {miss}, cols={df.columns}')
    df=df[need + ([ 'volume_base'] if 'volume_base' in df.columns else [])]
    if 'volume_base' not in df.columns: df['volume_base']=np.nan
    df['dt']=pd.to_datetime(df['dt'], utc=True)
    df=df.sort_values('dt').drop_duplicates('dt').reset_index(drop=True)
    for c in ['open','high','low','close','volume_quote','volume_base']:
        df[c]=pd.to_numeric(df[c], errors='coerce')
    df['interval']=interval
    return df

def ema(s,n): return s.ewm(span=n, adjust=False, min_periods=n).mean()

def rsi(close,n=14):
    delta=close.diff()
    up=delta.clip(lower=0)
    down=-delta.clip(upper=0)
    roll_up=up.ewm(alpha=1/n, adjust=False, min_periods=n).mean()
    roll_down=down.ewm(alpha=1/n, adjust=False, min_periods=n).mean()
    rs=roll_up/roll_down.replace(0,np.nan)
    return 100 - (100/(1+rs))

def atr(df,n=14):
    high,low,close=df['high'],df['low'],df['close']
    prev=close.shift(1)
    tr=pd.concat([(high-low),(high-prev).abs(),(low-prev).abs()],axis=1).max(axis=1)
    return tr.ewm(alpha=1/n, adjust=False, min_periods=n).mean()

def adx(df,n=14):
    high,low,close=df['high'],df['low'],df['close']
    up=high.diff(); down=-low.diff()
    plus_dm=np.where((up>down)&(up>0), up, 0.0)
    minus_dm=np.where((down>up)&(down>0), down, 0.0)
    tr=pd.concat([(high-low),(high-close.shift()).abs(),(low-close.shift()).abs()],axis=1).max(axis=1)
    atrv=tr.ewm(alpha=1/n, adjust=False, min_periods=n).mean()
    plus_di=100*pd.Series(plus_dm,index=df.index).ewm(alpha=1/n,adjust=False,min_periods=n).mean()/atrv
    minus_di=100*pd.Series(minus_dm,index=df.index).ewm(alpha=1/n,adjust=False,min_periods=n).mean()/atrv
    dx=100*((plus_di-minus_di).abs()/(plus_di+minus_di).replace(0,np.nan))
    return dx.ewm(alpha=1/n,adjust=False,min_periods=n).mean(), plus_di, minus_di

def compute_fractals(df, w=2):
    # Vectorized centered local extrema. In live mode, shift the output by w bars
    # if strict confirmation is required.
    h,l=df['high'],df['low']
    win=2*w+1
    roll_max=h.rolling(win, center=True, min_periods=win).max()
    roll_min=l.rolling(win, center=True, min_periods=win).min()
    top=(h.eq(roll_max) & h.gt(h.shift(1)) & h.gt(h.shift(-1))).fillna(False)
    bot=(l.eq(roll_min) & l.lt(l.shift(1)) & l.lt(l.shift(-1))).fillna(False)
    return top,bot

def build_strokes(df, top, bot, min_gap=4):
    # returns arrays: last_fractal_type, last_bi_direction based on alternating confirmed fractals
    n=len(df)
    last_dir=np.array(['none']*n, dtype=object)
    last_frac=np.array(['none']*n, dtype=object)
    stroke_count=np.zeros(n,dtype=int)
    pivots=[]  # tuples (idx,type,price)
    for i in range(n):
        cand=None
        if top.iloc[i]: cand=(i,'top',df['high'].iloc[i])
        elif bot.iloc[i]: cand=(i,'bottom',df['low'].iloc[i])
        if cand:
            if not pivots:
                pivots.append(cand)
            else:
                li,lt,lp=pivots[-1]
                ci,ct,cp=cand
                if ct==lt:
                    # same type keep more extreme
                    if (ct=='top' and cp>lp) or (ct=='bottom' and cp<lp):
                        pivots[-1]=cand
                elif ci-li>=min_gap:
                    pivots.append(cand)
        if pivots:
            last_frac[i]=pivots[-1][1]
        if len(pivots)>=2:
            a,b=pivots[-2],pivots[-1]
            if a[1]=='bottom' and b[1]=='top': last_dir[i]='up'
            elif a[1]=='top' and b[1]=='bottom': last_dir[i]='down'
            else: last_dir[i]='none'
            stroke_count[i]=len(pivots)-1
    return pd.Series(last_dir,index=df.index), pd.Series(last_frac,index=df.index), pd.Series(stroke_count,index=df.index)

def zhongshu_proxy(df, lookback=60):
    # pragmatic proxy: recent consolidation band using rolling 20%-80% price overlap and ATR normalization
    high_roll=df['high'].rolling(lookback,min_periods=max(20,lookback//3)).max()
    low_roll=df['low'].rolling(lookback,min_periods=max(20,lookback//3)).min()
    mid=(high_roll+low_roll)/2
    width=(high_roll-low_roll)
    atrv=df['atr14'].replace(0,np.nan)
    pos=(df['close']-mid)/width.replace(0,np.nan)
    compression=(width/atrv).replace([np.inf,-np.inf],np.nan)
    # score high means near center/consolidation; breakout positive/negative via pos
    return high_roll, low_roll, pos, compression

def add_features(df, interval):
    df=df.copy()
    c=df['close']
    df['ema20']=ema(c,20); df['ema50']=ema(c,50); df['ema200']=ema(c,200)
    macd_fast=ema(c,12); macd_slow=ema(c,26)
    df['macd_dif']=macd_fast-macd_slow
    df['macd_dea']=ema(df['macd_dif'],9)
    df['macd_hist']=(df['macd_dif']-df['macd_dea'])*2
    df['macd_hist_slope']=df['macd_hist'].diff()
    df['rsi14']=rsi(c,14)
    df['atr14']=atr(df,14)
    df['adx14'],df['plus_di'],df['minus_di']=adx(df,14)
    df['volume_z']=(df['volume_quote']-df['volume_quote'].rolling(96,min_periods=20).mean())/df['volume_quote'].rolling(96,min_periods=20).std().replace(0,np.nan)
    top,bot=compute_fractals(df,2)
    df['fractal_top']=top; df['fractal_bottom']=bot
    df['bi_direction'],df['last_fractal'],df['stroke_count']=build_strokes(df,top,bot,min_gap=3 if interval in ['5m','15m'] else 4)
    zh_hi,zh_lo,zh_pos,zh_comp=zhongshu_proxy(df, lookback={'5m':144,'15m':96,'30m':80,'1h':60,'4h':42,'1d':30}[interval])
    df['zhongshu_high_proxy']=zh_hi; df['zhongshu_low_proxy']=zh_lo; df['zhongshu_pos']=zh_pos; df['zhongshu_compression']=zh_comp
    # direction score per interval, -1 to +1-ish
    trend_score=(np.sign(c-df['ema20']).fillna(0)*0.25 + np.sign(c-df['ema50']).fillna(0)*0.25 + np.sign(c-df['ema200']).fillna(0)*0.20)
    macd_score=(np.sign(df['macd_hist']).fillna(0)*0.18 + np.sign(df['macd_hist_slope']).fillna(0)*0.07)
    rsi_score=((df['rsi14']-50)/50).clip(-1,1)*0.10
    di_score=np.sign(df['plus_di']-df['minus_di']).fillna(0)*0.10
    bi_score=df['bi_direction'].map({'up':0.15,'down':-0.15,'none':0}).fillna(0)
    z_score=np.where(df['zhongshu_pos']>0.55,0.10,np.where(df['zhongshu_pos']<-0.55,-0.10,0))
    df['tf_score']=(trend_score+macd_score+rsi_score+di_score+bi_score+z_score).clip(-1,1)
    df['tf_direction']=np.where(df['tf_score']>0.18,'long',np.where(df['tf_score']<-0.18,'short','neutral'))
    df['regime']=np.where(df['adx14']>=25,'trending',np.where(df['atr14']/df['close']>0.035,'high_vol','ranging'))
    return df

def direction_from_score(score):
    if score>=0.15: return 'long'
    if score<=-0.15: return 'short'
    return 'neutral'

def strength_from(raw, agreement):
    if agreement < 0.50: return 'conflicting'
    if raw >= 72 and agreement >= 0.67: return 'strong'
    if raw >= 62 and agreement >= 0.55: return 'moderate'
    return 'weak'

def wilson(k,n,z=1.96):
    if n<=0: return (None,None)
    p=k/n; denom=1+z*z/n
    center=(p+z*z/(2*n))/denom
    half=(z*math.sqrt((p*(1-p)+z*z/(4*n))/n))/denom
    return center-half, center+half

def evaluate(row, future):
    entry=row['price']; sig=row['signal']
    if len(future)==0: return None
    close_end=future['close'].iloc[-1]
    if sig=='long':
        future_return=(close_end-entry)/entry - 0.001
        mfe=(future['high'].max()-entry)/entry - 0.001
        mae=(future['low'].min()-entry)/entry - 0.001
    elif sig=='short':
        future_return=(entry-close_end)/entry - 0.001
        mfe=(entry-future['low'].min())/entry - 0.001
        mae=(entry-future['high'].max())/entry - 0.001
    else:
        return None
    return future_return,mfe,mae,future_return>0

# Load and compute features
raw={}
feat={}
for tf,z in ZIP_MAP.items():
    df=standardize(load_csv_from_zip(z),tf)
    raw[tf]=df
    feat[tf]=add_features(df,tf)
    feat[tf].tail(5000).to_csv(OUT/'data_feature_store'/f'btc_{tf}_features_preview_tail5000.csv',index=False)

# Common window from all feature dfs and requiring ema warmup (drop first 220 bars per df for stability)
starts=[]; ends=[]
for tf,df in feat.items():
    warm=min(220,len(df)-1)
    starts.append(df['dt'].iloc[warm])
    ends.append(df['dt'].iloc[-2]) # closed only / avoid last maybe incomplete
common_start=max(starts)
common_end=min(ends)
anchor=feat['1h'][(feat['1h']['dt']>=common_start)&(feat['1h']['dt']<=common_end)].copy().reset_index(drop=True)
# build merge_asof features for each tf
merged=anchor[['dt','open','high','low','close']].rename(columns={'open':'anchor_open','high':'anchor_high','low':'anchor_low','close':'anchor_close'})
for tf in ['5m','15m','30m','1h','4h','1d']:
    cols=['dt','close','tf_score','tf_direction','regime','ema20','ema50','ema200','macd_hist','macd_hist_slope','rsi14','adx14','plus_di','minus_di','volume_z','bi_direction','last_fractal','stroke_count','zhongshu_pos','zhongshu_high_proxy','zhongshu_low_proxy']
    d=feat[tf][cols].copy().sort_values('dt')
    d=d.add_suffix('_'+tf).rename(columns={'dt_'+tf:'dt'})
    merged=pd.merge_asof(merged.sort_values('dt'), d, on='dt', direction='backward')

# Score hierarchy weights: background/operation/trigger, not simple equal voting
weights={'1d':0.18,'4h':0.25,'1h':0.27,'30m':0.18,'15m':0.08,'5m':0.04}
records=[]
for idx,row in merged.iterrows():
    if any(pd.isna(row.get(f'tf_score_{tf}',np.nan)) for tf in weights):
        continue
    scores={tf:float(row[f'tf_score_{tf}']) for tf in weights}
    mtf_score=sum(scores[tf]*weights[tf] for tf in weights)
    signal=direction_from_score(mtf_score)
    if signal=='neutral':
        continue
    dirs={tf:row[f'tf_direction_{tf}'] for tf in weights}
    aligned=sum(1 for tf,d in dirs.items() if d==signal)
    agreement=aligned/len(weights)
    raw_score=round(min(95,max(50,50+abs(mtf_score)*50)),2)
    strength=strength_from(raw_score,agreement)
    # lifecycle-like downgrade if background contradicts operation/trigger
    lifecycle='active'
    if signal=='long' and dirs['1d']=='short': lifecycle='downgraded_background_conflict'
    if signal=='short' and dirs['1d']=='long': lifecycle='downgraded_background_conflict'
    if strength=='conflicting': lifecycle='observe_conflicting'
    main_regime=row['regime_4h'] if pd.notna(row['regime_4h']) else 'unknown'
    ts=row['dt']
    features={
        'scores':scores,'directions':dirs,'agreement':agreement,
        'background_level':'1d','operation_level':'4h/1h','trigger_level':'30m/15m/5m',
        'lifecycle':lifecycle,
        'price_1h':float(row['close_1h']),
        'macd_hist_1h':float(row['macd_hist_1h']), 'macd_hist_4h':float(row['macd_hist_4h']), 'macd_hist_1d':float(row['macd_hist_1d']),
        'rsi_1h':float(row['rsi14_1h']), 'rsi_4h':float(row['rsi14_4h']), 'rsi_1d':float(row['rsi14_1d']),
        'zhongshu_pos_1h':None if pd.isna(row['zhongshu_pos_1h']) else float(row['zhongshu_pos_1h']),
        'zhongshu_pos_4h':None if pd.isna(row['zhongshu_pos_4h']) else float(row['zhongshu_pos_4h']),
        'zhongshu_high_1h':None if pd.isna(row['zhongshu_high_proxy_1h']) else float(row['zhongshu_high_proxy_1h']),
        'zhongshu_low_1h':None if pd.isna(row['zhongshu_low_proxy_1h']) else float(row['zhongshu_low_proxy_1h']),
        'zhongshu_high_4h':None if pd.isna(row['zhongshu_high_proxy_4h']) else float(row['zhongshu_high_proxy_4h']),
        'zhongshu_low_4h':None if pd.isna(row['zhongshu_low_proxy_4h']) else float(row['zhongshu_low_proxy_4h']),
    }
    records.append({
        'signal_id':f"btcusdt_{ts.strftime('%Y%m%dT%H%M%SZ')}_1h_{signal}_chanlun_mtf_v0_2",
        'symbol':'BTCUSDT','ts':ts.isoformat(),'timeframe':'1h','price':float(row['close_1h']),
        'signal':signal,'raw_score':raw_score,'strength':strength,'regime':str(main_regime),
        'features':json.dumps(features, ensure_ascii=False),
        'exchange':'mixed_gate_binance','schema_version':'0.2.0','model_version':'chanlun_mtf_adapter_v0_2',
        'label_horizon_bars':12,'future_return':np.nan,'mfe':np.nan,'mae':np.nan,'hit':np.nan,'finalized':False,
        '_idx':idx,
    })
rec=pd.DataFrame(records)
# Evaluate using anchor 1h future windows; index mapping by dt
anchor_eval=anchor[['dt','high','low','close']].reset_index(drop=True)
dt_to_i={dt:i for i,dt in enumerate(anchor_eval['dt'])}
for i,r in rec.iterrows():
    ts=pd.Timestamp(r['ts'])
    ai=dt_to_i.get(ts)
    if ai is None or ai+12>=len(anchor_eval): continue
    future=anchor_eval.iloc[ai+1:ai+13]
    ev=evaluate(r,future)
    if ev:
        rec.at[i,'future_return']=ev[0]; rec.at[i,'mfe']=ev[1]; rec.at[i,'mae']=ev[2]; rec.at[i,'hit']=bool(ev[3]); rec.at[i,'finalized']=True
rec=rec[rec['finalized']==True].copy()
rec.drop(columns=['_idx'], inplace=True)
# Save records
rec.to_csv(OUT/'data_feature_store'/'btcusdt_chanlun_mtf_signal_records_v0_2.csv',index=False)
with open(OUT/'data_feature_store'/'btcusdt_chanlun_mtf_signal_records_v0_2.jsonl','w') as f:
    for _,r in rec.iterrows():
        d=r.to_dict()
        for k in ['future_return','mfe','mae']:
            d[k]=None if pd.isna(d[k]) else float(d[k])
        d['hit']=bool(d['hit'])
        f.write(json.dumps(d, ensure_ascii=False, default=str)+'\n')
# Calibration summaries
rec['score_bucket']=(np.floor(rec['raw_score']/5)*5).astype(int).astype(str)+'-'+(np.floor(rec['raw_score']/5)*5+5).astype(int).astype(str)
keys=['signal','strength','score_bucket','regime']
rows=[]
for key,g in rec.groupby(keys, dropna=False):
    n=len(g); k=int(g['hit'].sum()); lo,hi=wilson(k,n)
    wins=g[g['future_return']>0]['future_return']; losses=g[g['future_return']<=0]['future_return']
    avg_win=float(wins.mean()) if len(wins) else None
    avg_loss=float(losses.mean()) if len(losses) else None
    rr=(avg_win/abs(avg_loss)) if avg_win is not None and avg_loss not in (None,0) else None
    conf='insufficient' if n<20 else ('weak' if n<50 else ('normal' if n<200 else 'strong'))
    rows.append(dict(zip(keys,key), sample_size=n, wins=k, win_rate=k/n, win_rate_ci_low=lo, win_rate_ci_high=hi,
                     avg_return=float(g['future_return'].mean()), median_return=float(g['future_return'].median()), avg_win=avg_win, avg_loss=avg_loss,
                     mfe_mean=float(g['mfe'].mean()), mae_mean=float(g['mae'].mean()), rr_estimate=rr, confidence_level=conf))
cal=pd.DataFrame(rows).sort_values(['sample_size','win_rate'],ascending=[False,False])
cal.to_csv(OUT/'data_feature_store'/'calibration_chanlun_mtf_by_bucket.csv',index=False)
cal.to_json(OUT/'data_feature_store'/'calibration_chanlun_mtf_by_bucket.json',orient='records',force_ascii=False,indent=2)
# latest aligned endpoint snapshot
latest_ts=common_end
last=merged[merged['dt']<=latest_ts].iloc[-1]
# compute a latest row signal manually from rec closest or from scores
latest_recs=rec[rec['ts']==latest_ts.isoformat()]
if len(latest_recs)==0:
    # find last generated record before endpoint
    latest_rec=rec.iloc[-1].to_dict()
else:
    latest_rec=latest_recs.iloc[-1].to_dict()
# match calibration for latest rec group
mask=(cal['signal']==latest_rec['signal'])&(cal['strength']==latest_rec['strength'])&(cal['score_bucket']==latest_rec['score_bucket'])&(cal['regime']==latest_rec['regime'])
latest_cal=cal[mask].iloc[0].to_dict() if mask.any() else {}
# signal probabilities from current structural scores (scenario)
features=json.loads(latest_rec['features'])
scores=features['scores']; dirs=features['directions']; price=latest_rec['price']
scenario={
    'anchor_ts':latest_rec['ts'],
    'price':price,
    'current_signal':{'signal':latest_rec['signal'],'raw_score':latest_rec['raw_score'],'strength':latest_rec['strength'],'regime':latest_rec['regime'],'lifecycle':features.get('lifecycle')},
    'level_directions':dirs,
    'level_scores':scores,
    'calibration_bucket':latest_cal,
    'key_levels':{
        '1h_zhongshu_low':features.get('zhongshu_low_1h'), '1h_zhongshu_high':features.get('zhongshu_high_1h'),
        '4h_zhongshu_low':features.get('zhongshu_low_4h'), '4h_zhongshu_high':features.get('zhongshu_high_4h')
    },
    'note':'Aligned to the common closed-only endpoint; not necessarily the newest live market because some uploaded low timeframes ended earlier.'
}
with open(OUT/'snapshots'/'latest_aligned_chanlun_mtf_snapshot.json','w') as f: json.dump(scenario,f,ensure_ascii=False,indent=2,default=str)
# Summary stats
summary={
    'stage':'Stage 3 - chanlun MTF adapter preview',
    'model_version':'chanlun_mtf_adapter_v0_2',
    'common_start':common_start.isoformat(), 'common_end':common_end.isoformat(),
    'anchor_timeframe':'1h','label_horizon_bars':12,'cost_bps':10,
    'records_finalized':int(len(rec)),
    'by_signal':rec['signal'].value_counts().to_dict(),
    'by_strength':rec['strength'].value_counts().to_dict(),
    'overall_win_rate':float(rec['hit'].mean()),
    'overall_avg_return':float(rec['future_return'].mean()),
    'latest_aligned_signal':scenario['current_signal'],
    'warning':'This adapter is a transparent chanlun-inspired multi-timeframe bridge. In the local project it should be wired to the existing ChanlunAnalyzer/MultiTimeframeAnalyzer outputs.'
}
with open(OUT/'data_feature_store'/'stage3_summary.json','w') as f: json.dump(summary,f,ensure_ascii=False,indent=2,default=str)
pd.DataFrame([summary]).to_csv(OUT/'data_feature_store'/'stage3_summary.csv',index=False)
# Write code files
(OUT/'src_core_signals'/'closed_kline.py').write_text(r'''from __future__ import annotations
from datetime import datetime, timezone
import pandas as pd

INTERVAL_SECONDS = {"5m":300,"15m":900,"30m":1800,"1h":3600,"4h":14400,"1d":86400}

def filter_closed_only(df: pd.DataFrame, interval: str, now: datetime | None = None, ts_col: str = "dt") -> pd.DataFrame:
    """Return rows whose candle open time + interval <= now.

    This prevents an in-progress 5m/30m/4h/1d candle from contaminating
    MACD, fractal, bi/segment and calibration output.
    """
    if now is None:
        now = datetime.now(timezone.utc)
    out = df.copy()
    out[ts_col] = pd.to_datetime(out[ts_col], utc=True)
    close_time = out[ts_col] + pd.to_timedelta(INTERVAL_SECONDS[interval], unit="s")
    return out.loc[close_time <= pd.Timestamp(now)].copy()
''',encoding='utf-8')
(OUT/'src_core_signals'/'lifecycle.py').write_text(r'''from __future__ import annotations
from dataclasses import dataclass
from typing import Literal

Lifecycle = Literal["active", "downgraded", "invalidated", "reactivated", "observe"]

@dataclass(slots=True)
class LifecycleResult:
    status: Lifecycle
    reason: str


def evaluate_lifecycle(previous_signal: str | None, previous_strength: str | None, current_signal: str, current_strength: str, level_directions: dict[str, str]) -> LifecycleResult:
    """Evaluate whether a prior signal is still executable.

    Rule intent:
    - Short/long signals are downgraded when operation/trigger levels repair against it.
    - Signals are invalidated only when the opposite direction confirms on 4h/1h and background no longer supports the old direction.
    """
    if previous_signal is None:
        return LifecycleResult("active" if current_signal != "neutral" else "observe", "no previous signal")
    if current_signal == previous_signal:
        if current_strength in {"strong", "moderate"}:
            return LifecycleResult("active", "same direction remains supported")
        return LifecycleResult("downgraded", "same direction but strength weakened")
    if current_signal == "neutral":
        return LifecycleResult("downgraded", "current signal neutralized")
    # opposite direction: require 4h + 1h agreement before invalidating
    if level_directions.get("4h") == current_signal and level_directions.get("1h") == current_signal:
        return LifecycleResult("invalidated", "4h and 1h confirmed opposite direction")
    return LifecycleResult("observe", "opposite trigger exists but higher-level confirmation is incomplete")
''',encoding='utf-8')
(OUT/'src_core_signals'/'chanlun_signal_adapter.py').write_text(r'''from __future__ import annotations
from dataclasses import dataclass
from datetime import datetime
from typing import Any

from .models import FeatureSnapshot

@dataclass(slots=True)
class ChanlunMTFConfig:
    symbol: str = "BTCUSDT"
    background_level: str = "1d"
    operation_levels: tuple[str, ...] = ("4h", "1h")
    trigger_levels: tuple[str, ...] = ("30m", "15m", "5m")
    model_version: str = "chanlun_mtf_adapter_v0_2"
    schema_version: str = "0.2.0"


class ChanlunSignalAdapter:
    """Bridge existing ChanlunAnalyzer / MultiTimeframeAnalyzer output into FeatureSnapshot.

    Expected analyzer_result shape is intentionally loose so it can wrap your existing project output:
      {
        "signal": "long|short|neutral",
        "raw_score": 72.0,
        "strength": "strong|moderate|weak|conflicting",
        "regime": "trending|ranging|high_vol|unknown",
        "price": 63186.3,
        "levels": {"1d": {...}, "4h": {...}, ...},
        "lifecycle": "active|downgraded|invalidated|observe"
      }
    """

    def __init__(self, config: ChanlunMTFConfig | None = None):
        self.config = config or ChanlunMTFConfig()

    def to_snapshot(self, ts: datetime, analyzer_result: dict[str, Any]) -> FeatureSnapshot:
        levels = analyzer_result.get("levels", {})
        features = {
            "background_level": self.config.background_level,
            "operation_levels": list(self.config.operation_levels),
            "trigger_levels": list(self.config.trigger_levels),
            "levels": levels,
            "lifecycle": analyzer_result.get("lifecycle", "active"),
            "agreement": analyzer_result.get("agreement"),
            "key_levels": analyzer_result.get("key_levels", {}),
        }
        signal = analyzer_result.get("signal", "neutral")
        return FeatureSnapshot(
            signal_id=f"{self.config.symbol.lower()}_{ts.strftime('%Y%m%dT%H%M%SZ')}_1h_{signal}_{self.config.model_version}",
            symbol=self.config.symbol,
            ts=ts,
            timeframe=analyzer_result.get("timeframe", "1h"),
            price=float(analyzer_result["price"]),
            signal=signal,
            raw_score=float(analyzer_result.get("raw_score", 50.0)),
            strength=analyzer_result.get("strength", "weak"),
            regime=analyzer_result.get("regime", "unknown"),
            features=features,
            exchange=analyzer_result.get("exchange", "mixed"),
            source_priority=int(analyzer_result.get("source_priority", 0)),
            schema_version=self.config.schema_version,
            model_version=self.config.model_version,
        )
''',encoding='utf-8')
(OUT/'src_core_signals'/'position_sizing.py').write_text(r'''from __future__ import annotations
from .models import CalibrationResult

def suggest_position(calibration: CalibrationResult) -> float:
    """Conservative MVP sizing. Returns fraction of account equity allocation, not risk."""
    if calibration.sample_size < 20 or calibration.win_rate is None:
        return 0.0
    if calibration.win_rate_ci_low is not None and calibration.win_rate_ci_low < 0.50:
        return 0.0
    if calibration.mae_mean is not None and calibration.mae_mean < -0.025:
        return 0.0
    rr = calibration.rr_estimate or 0.0
    if calibration.sample_size >= 200 and calibration.win_rate >= 0.70 and rr >= 1.30:
        return 0.50
    if calibration.sample_size >= 50 and calibration.win_rate >= 0.66 and rr >= 1.20:
        return 0.30
    if calibration.sample_size >= 20 and calibration.win_rate >= 0.60:
        return 0.10
    return 0.0
''',encoding='utf-8')
# scripts
(OUT/'scripts'/'run_stage3_chanlun_mtf_preview.py').write_text('''#!/usr/bin/env python3\n"""Reference script generated in Stage 3.\nUse build_stage3.py in the artifact root as the runnable offline example.\nIn the local project, migrate src_core_signals/* into src/core/signals/ and wire ChanlunSignalAdapter to existing ChanlunAnalyzer/MultiTimeframeAnalyzer.\n"""\nprint("Run build_stage3.py from the artifact source package, or integrate src_core_signals into your project.")\n''',encoding='utf-8')
# tests
(OUT/'tests'/'test_stage3_contract.py').write_text(r'''from datetime import datetime, timezone
import pandas as pd

from src_core_signals.closed_kline import filter_closed_only
from src_core_signals.lifecycle import evaluate_lifecycle


def test_closed_only_filters_open_candle():
    df = pd.DataFrame({"dt": ["2026-07-10T00:00:00Z", "2026-07-10T00:05:00Z"], "close": [1, 2]})
    out = filter_closed_only(df, "5m", datetime(2026, 7, 10, 0, 6, tzinfo=timezone.utc))
    assert len(out) == 1
    assert out["close"].iloc[0] == 1


def test_lifecycle_downgrade_when_neutralized():
    res = evaluate_lifecycle("short", "strong", "neutral", "weak", {"4h":"neutral","1h":"long"})
    assert res.status == "downgraded"


def test_lifecycle_invalidates_on_4h_1h_opposite():
    res = evaluate_lifecycle("short", "strong", "long", "moderate", {"4h":"long","1h":"long"})
    assert res.status == "invalidated"
''',encoding='utf-8')
# Report
sig_counts=rec['signal'].value_counts().to_dict(); str_counts=rec['strength'].value_counts().to_dict()
# top relevant buckets by sample n and win rate with n>=50
top=cal[cal['sample_size']>=50].sort_values(['win_rate','sample_size'],ascending=[False,False]).head(10)
report=f'''# BTCUSDT Stage 3：缠论多周期信号接入预演报告

## 阶段定位

Stage 3 的目标是把 Stage 2 的 `baseline_mtf_v0_1` 从“管道测试信号”升级为“缠论级别递归思想下的多周期信号适配器”。本阶段在当前会话里不能直接修改你的本地项目源码，因此我完成的是：

1. 基于你上传的 BTCUSDT 六周期历史数据，生成 `chanlun_mtf_adapter_v0_2` 离线预演样本池；
2. 输出可迁入项目的 `closed_kline`、`lifecycle`、`chanlun_signal_adapter`、`position_sizing` 模块；
3. 生成新的 SignalRecord 与 calibration summary；
4. 保留明确限制：本适配器是透明的缠论启发式桥接层，落地到本地项目时应接入已有 `ChanlunAnalyzer / MultiTimeframeAnalyzer` 的真实结果。

## 数据窗口

- 共同窗口：`{common_start.isoformat()}` 到 `{common_end.isoformat()}`
- 锚定周期：1h
- 标签窗口：12 根 1h K线，即约 12 小时
- 成本口径：10 bps
- 模型版本：`chanlun_mtf_adapter_v0_2`

## 样本池结果

- finalized SignalRecord：{len(rec):,} 条
- overall win rate：{rec['hit'].mean():.2%}
- overall avg_return：{rec['future_return'].mean():.4%}
- signal 分布：`{sig_counts}`
- strength 分布：`{str_counts}`

## 当前 aligned endpoint 快照

> 注意：该快照对齐到所有周期共同 closed-only 终点，不等于最新实时市场。

- 时间：`{scenario['anchor_ts']}`
- 价格：`{scenario['price']:.2f}`
- 信号：`{scenario['current_signal']['signal']}`
- raw_score：`{scenario['current_signal']['raw_score']}`
- strength：`{scenario['current_signal']['strength']}`
- lifecycle：`{scenario['current_signal']['lifecycle']}`
- 各级别方向：`{scenario['level_directions']}`

## 本阶段新增的关键机制

### 1. Closed-only K线过滤

实时分析必须先过滤未收盘 K线，否则 4h/1d 刚开盘的 K线会污染 MACD、分型、笔、线段、中枢和校准结果。

### 2. 信号生命周期

新增四类状态：

- `active`：信号仍有效；
- `downgraded`：原方向没有完全失效，但执行级别下降；
- `invalidated`：操作级别和触发级别反向确认；
- `observe`：多周期冲突，暂不执行。

### 3. 缠论级别递归权重

本阶段不是等权投票，而是按角色分层：

- 1d：background level；
- 4h / 1h：operation level；
- 30m / 15m / 5m：trigger level。

这避免把 5m 短线反弹误判成日线反转，也避免把日线压制误判成 5m 不能交易。

## 重要限制

`chanlun_mtf_adapter_v0_2` 仍是会话内生成的透明预演模型，不等价于你本地项目中真实的缠论算法。下一步需要在本地项目中把已有模块接进来：

- `src/core/chanlun/analyzer.py`
- `src/core/chanlun/multi_timeframe.py`
- `src/core/chanlun/dynamics.py`
- `src/core/chanlun/regime.py`

然后由真实缠论输出填充 `FeatureSnapshot`。

## 下一步 Stage 4

Stage 4 应进入“本地项目集成”：

1. 把 `src_core_signals/*` 迁入 `src/core/signals/`；
2. 在 `run_backtest.py` 或 `run_backtest_multi.py` 中调用 `ChanlunSignalAdapter.to_snapshot()`；
3. 每个真实缠论信号生成 `SignalRecord`；
4. 使用 `calibration.py` 查询相似历史样本；
5. 修改 `run_live_monitor.py`，实时输出 `raw_score` 与 `historical_win_rate`；
6. 样本不足时强制降级为 observe；
7. 对 strong short 做 `active / downgraded / invalidated / reactivated` 生命周期判断。
'''
(OUT/'reports'/'stage3_chanlun_mtf_adapter_report.md').write_text(report,encoding='utf-8')
# compressed context
context=f'''# 压缩上下文：BTCUSDT Signal Calibration Center Stage 3 完成状态

## 已完成
- Stage 1：六周期 BTCUSDT 数据底座验收通过。
- Stage 2：Feature Store MVP + baseline SignalRecord 管道跑通。
- Stage 3：生成 `chanlun_mtf_adapter_v0_2` 缠论多周期适配器预演样本池。

## Stage 3 核心输出
- 共同窗口：{common_start.isoformat()} 到 {common_end.isoformat()}
- 锚定周期：1h
- 标签窗口：12 bars / 约 12 小时
- finalized records：{len(rec):,}
- overall win rate：{rec['hit'].mean():.2%}
- 模型版本：chanlun_mtf_adapter_v0_2

## Stage 3 新增模块
- `closed_kline.py`：过滤未收盘 K线。
- `lifecycle.py`：active / downgraded / invalidated / observe。
- `chanlun_signal_adapter.py`：把真实 ChanlunAnalyzer/MultiTimeframeAnalyzer 输出转成 FeatureSnapshot。
- `position_sizing.py`：基于校准结果的保守仓位建议。

## 重要限制
当前 stage3 是缠论启发式适配预演，不是用户本地项目真实 ChanlunAnalyzer 的直接运行结果。下一步应在本地项目中把 `src_core_signals/*` 迁入 `src/core/signals/`，再把真实 analyzer 输出接入 `FeatureSnapshot`。

## 下一步
Stage 4：本地项目集成与真实信号回测注入。重点改造 `run_backtest.py / run_backtest_multi.py / run_live_monitor.py`。
'''
(OUT/'reports'/'CONTEXT_COMPRESSED_FOR_NEXT_STEP.md').write_text(context,encoding='utf-8')
# Also include build script itself
shutil.copy('/mnt/data/build_stage3.py', OUT/'scripts'/'build_stage3_offline_preview.py')
# zip
zip_path=BASE/'btc_signal_calibration_stage3_chanlun_mtf_adapter.zip'
if zip_path.exists(): zip_path.unlink()
shutil.make_archive(str(zip_path).replace('.zip',''), 'zip', OUT)
print(json.dumps(summary,ensure_ascii=False,indent=2,default=str))
print(zip_path)
