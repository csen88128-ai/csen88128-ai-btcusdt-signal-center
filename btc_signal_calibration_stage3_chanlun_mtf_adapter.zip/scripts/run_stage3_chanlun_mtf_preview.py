#!/usr/bin/env python3
"""Reference script generated in Stage 3.
Use build_stage3.py in the artifact root as the runnable offline example.
In the local project, migrate src_core_signals/* into src/core/signals/ and wire ChanlunSignalAdapter to existing ChanlunAnalyzer/MultiTimeframeAnalyzer.
"""
print("Run build_stage3.py from the artifact source package, or integrate src_core_signals into your project.")
