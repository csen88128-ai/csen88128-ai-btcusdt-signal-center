from __future__ import annotations
from .models import CalibrationResult

def suggest_position(calibration: CalibrationResult) -> float:
    """Conservative MVP sizing. Returns fraction of account equity allocation, not risk."""
    if calibration.sample_size < 20 or calibration.win_rate is None:
        return 0.0
    if calibration.win_rate_ci_low is not None and calibration.win_rate_ci_low < 0.50:
        return 0.0
    if calibration.mae_mean is not None and calibration.mae_mean < -0.025:
        return 0.0
    rr = calibration.rr_estimate or 0.0
    if calibration.sample_size >= 200 and calibration.win_rate >= 0.70 and rr >= 1.30:
        return 0.50
    if calibration.sample_size >= 50 and calibration.win_rate >= 0.66 and rr >= 1.20:
        return 0.30
    if calibration.sample_size >= 20 and calibration.win_rate >= 0.60:
        return 0.10
    return 0.0
