from __future__ import annotations

import math
from statistics import mean, median
from typing import Sequence, Mapping, Any

def wilson_ci(k: int, n: int, z: float = 1.96) -> tuple[float | None, float | None]:
    if n <= 0:
        return None, None
    p = k / n
    denom = 1 + z*z/n
    centre = (p + z*z/(2*n)) / denom
    adj = z * math.sqrt((p*(1-p) + z*z/(4*n)) / n) / denom
    return max(0.0, centre - adj), min(1.0, centre + adj)

def confidence_level(n: int) -> str:
    if n < 20:
        return "insufficient"
    if n < 50:
        return "weak"
    if n < 200:
        return "normal"
    return "strong"

def summarize_records(records: Sequence[Mapping[str, Any]]) -> dict[str, Any]:
    finalized = [r for r in records if r.get("finalized") and r.get("outcome")]
    n = len(finalized)
    if n == 0:
        return {"sample_size": 0, "confidence_level": "insufficient"}
    hits = [bool(r["outcome"].get("hit")) for r in finalized]
    returns = [float(r["outcome"].get("future_return", 0.0)) for r in finalized]
    mfes = [float(r["outcome"].get("mfe", 0.0)) for r in finalized if r["outcome"].get("mfe") is not None]
    maes = [float(r["outcome"].get("mae", 0.0)) for r in finalized if r["outcome"].get("mae") is not None]
    wins = [x for x in returns if x > 0]
    losses = [x for x in returns if x <= 0]
    k = sum(hits)
    low, high = wilson_ci(k, n)
    avg_win = mean(wins) if wins else None
    avg_loss = mean(losses) if losses else None
    rr = (avg_win / abs(avg_loss)) if avg_win is not None and avg_loss and avg_loss < 0 else None
    return {
        "sample_size": n,
        "win_rate": k / n,
        "win_rate_ci_low": low,
        "win_rate_ci_high": high,
        "avg_return": mean(returns),
        "median_return": median(returns),
        "avg_win": avg_win,
        "avg_loss": avg_loss,
        "mfe_mean": mean(mfes) if mfes else None,
        "mae_mean": mean(maes) if maes else None,
        "rr_estimate": rr,
        "confidence_level": confidence_level(n),
    }
