from __future__ import annotations
from dataclasses import dataclass
from typing import Literal

Lifecycle = Literal["active", "downgraded", "invalidated", "reactivated", "observe"]

@dataclass(slots=True)
class LifecycleResult:
    status: Lifecycle
    reason: str


def evaluate_lifecycle(previous_signal: str | None, previous_strength: str | None, current_signal: str, current_strength: str, level_directions: dict[str, str]) -> LifecycleResult:
    """Evaluate whether a prior signal is still executable.

    Rule intent:
    - Short/long signals are downgraded when operation/trigger levels repair against it.
    - Signals are invalidated only when the opposite direction confirms on 4h/1h and background no longer supports the old direction.
    """
    if previous_signal is None:
        return LifecycleResult("active" if current_signal != "neutral" else "observe", "no previous signal")
    if current_signal == previous_signal:
        if current_strength in {"strong", "moderate"}:
            return LifecycleResult("active", "same direction remains supported")
        return LifecycleResult("downgraded", "same direction but strength weakened")
    if current_signal == "neutral":
        return LifecycleResult("downgraded", "current signal neutralized")
    # opposite direction: require 4h + 1h agreement before invalidating
    if level_directions.get("4h") == current_signal and level_directions.get("1h") == current_signal:
        return LifecycleResult("invalidated", "4h and 1h confirmed opposite direction")
    return LifecycleResult("observe", "opposite trigger exists but higher-level confirmation is incomplete")
