from __future__ import annotations

from dataclasses import dataclass, field, asdict
from datetime import datetime
from typing import Literal, Optional, Dict, Any

Direction = Literal["long", "short", "neutral"]
Strength = Literal["weak", "moderate", "strong", "conflicting"]
Regime = Literal["trending", "ranging", "high_vol", "unknown"]

@dataclass(slots=True)
class FeatureSnapshot:
    signal_id: str
    symbol: str
    ts: datetime
    timeframe: str
    price: float
    signal: Direction
    raw_score: float
    strength: Strength
    regime: Regime = "unknown"
    features: Dict[str, Any] = field(default_factory=dict)
    exchange: str = "unknown"
    source_priority: int = 0
    schema_version: str = "0.1.0"
    model_version: str = "unknown"

@dataclass(slots=True)
class SignalRecord:
    snapshot: FeatureSnapshot
    label_horizon_bars: int
    future_return: Optional[float] = None
    mfe: Optional[float] = None
    mae: Optional[float] = None
    hit: Optional[bool] = None
    ingest_ts: datetime = field(default_factory=datetime.utcnow)
    finalized: bool = False

@dataclass(slots=True)
class CalibrationResult:
    sample_size: int
    win_rate: Optional[float]
    win_rate_ci_low: Optional[float]
    win_rate_ci_high: Optional[float]
    avg_return: Optional[float]
    median_return: Optional[float]
    avg_win: Optional[float]
    avg_loss: Optional[float]
    mfe_mean: Optional[float]
    mae_mean: Optional[float]
    rr_estimate: Optional[float]
    confidence_level: str

def to_dict(obj):
    return asdict(obj)
