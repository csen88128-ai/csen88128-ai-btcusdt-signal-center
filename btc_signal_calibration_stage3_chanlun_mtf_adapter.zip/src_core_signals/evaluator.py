from __future__ import annotations

import pandas as pd

def evaluate_directional_outcome(df: pd.DataFrame, index: int, direction: str, horizon_bars: int, cost: float = 0.001) -> dict:
    price = float(df.iloc[index]["close"])
    future = df.iloc[index + 1:index + 1 + horizon_bars]
    if len(future) < horizon_bars:
        return {"finalized": False}
    future_close = float(future.iloc[-1]["close"])
    if direction == "long":
        future_return = future_close / price - 1 - cost
        mfe = float(future["high"].max()) / price - 1
        mae = float(future["low"].min()) / price - 1
    elif direction == "short":
        future_return = price / future_close - 1 - cost
        mfe = price / float(future["low"].min()) - 1
        mae = price / float(future["high"].max()) - 1
    else:
        future_return, mfe, mae = 0.0, 0.0, 0.0
    return {"future_return": future_return, "mfe": mfe, "mae": mae, "hit": future_return > 0, "finalized": True}
