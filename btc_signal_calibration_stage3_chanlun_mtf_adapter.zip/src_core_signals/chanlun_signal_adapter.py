from __future__ import annotations
from dataclasses import dataclass
from datetime import datetime
from typing import Any

from .models import FeatureSnapshot

@dataclass(slots=True)
class ChanlunMTFConfig:
    symbol: str = "BTCUSDT"
    background_level: str = "1d"
    operation_levels: tuple[str, ...] = ("4h", "1h")
    trigger_levels: tuple[str, ...] = ("30m", "15m", "5m")
    model_version: str = "chanlun_mtf_adapter_v0_2"
    schema_version: str = "0.2.0"


class ChanlunSignalAdapter:
    """Bridge existing ChanlunAnalyzer / MultiTimeframeAnalyzer output into FeatureSnapshot.

    Expected analyzer_result shape is intentionally loose so it can wrap your existing project output:
      {
        "signal": "long|short|neutral",
        "raw_score": 72.0,
        "strength": "strong|moderate|weak|conflicting",
        "regime": "trending|ranging|high_vol|unknown",
        "price": 63186.3,
        "levels": {"1d": {...}, "4h": {...}, ...},
        "lifecycle": "active|downgraded|invalidated|observe"
      }
    """

    def __init__(self, config: ChanlunMTFConfig | None = None):
        self.config = config or ChanlunMTFConfig()

    def to_snapshot(self, ts: datetime, analyzer_result: dict[str, Any]) -> FeatureSnapshot:
        levels = analyzer_result.get("levels", {})
        features = {
            "background_level": self.config.background_level,
            "operation_levels": list(self.config.operation_levels),
            "trigger_levels": list(self.config.trigger_levels),
            "levels": levels,
            "lifecycle": analyzer_result.get("lifecycle", "active"),
            "agreement": analyzer_result.get("agreement"),
            "key_levels": analyzer_result.get("key_levels", {}),
        }
        signal = analyzer_result.get("signal", "neutral")
        return FeatureSnapshot(
            signal_id=f"{self.config.symbol.lower()}_{ts.strftime('%Y%m%dT%H%M%SZ')}_1h_{signal}_{self.config.model_version}",
            symbol=self.config.symbol,
            ts=ts,
            timeframe=analyzer_result.get("timeframe", "1h"),
            price=float(analyzer_result["price"]),
            signal=signal,
            raw_score=float(analyzer_result.get("raw_score", 50.0)),
            strength=analyzer_result.get("strength", "weak"),
            regime=analyzer_result.get("regime", "unknown"),
            features=features,
            exchange=analyzer_result.get("exchange", "mixed"),
            source_priority=int(analyzer_result.get("source_priority", 0)),
            schema_version=self.config.schema_version,
            model_version=self.config.model_version,
        )
