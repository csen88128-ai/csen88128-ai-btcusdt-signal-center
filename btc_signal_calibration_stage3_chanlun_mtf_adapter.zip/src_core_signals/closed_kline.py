from __future__ import annotations
from datetime import datetime, timezone
import pandas as pd

INTERVAL_SECONDS = {"5m":300,"15m":900,"30m":1800,"1h":3600,"4h":14400,"1d":86400}

def filter_closed_only(df: pd.DataFrame, interval: str, now: datetime | None = None, ts_col: str = "dt") -> pd.DataFrame:
    """Return rows whose candle open time + interval <= now.

    This prevents an in-progress 5m/30m/4h/1d candle from contaminating
    MACD, fractal, bi/segment and calibration output.
    """
    if now is None:
        now = datetime.now(timezone.utc)
    out = df.copy()
    out[ts_col] = pd.to_datetime(out[ts_col], utc=True)
    close_time = out[ts_col] + pd.to_timedelta(INTERVAL_SECONDS[interval], unit="s")
    return out.loc[close_time <= pd.Timestamp(now)].copy()
