from __future__ import annotations

import json
from pathlib import Path
from typing import Iterable, Dict, Any, Optional, List

class JsonlFeatureStore:
    def __init__(self, path: str | Path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def append_dict(self, record: Dict[str, Any]) -> None:
        with self.path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(record, ensure_ascii=False) + "\n")

    def load(self) -> List[Dict[str, Any]]:
        if not self.path.exists():
            return []
        with self.path.open("r", encoding="utf-8") as f:
            return [json.loads(line) for line in f if line.strip()]

    def query_similar(
        self,
        *,
        symbol: str,
        timeframe: str,
        signal: str,
        strength: Optional[str] = None,
        score_min: Optional[float] = None,
        score_max: Optional[float] = None,
        regime: Optional[str] = None,
        model_version: Optional[str] = None,
        finalized_only: bool = True,
    ) -> list[Dict[str, Any]]:
        out = []
        for r in self.load():
            if finalized_only and not r.get("finalized", False):
                continue
            if r.get("symbol") != symbol or r.get("timeframe") != timeframe or r.get("signal") != signal:
                continue
            if strength and r.get("strength") != strength:
                continue
            if regime and r.get("regime") != regime:
                continue
            if model_version and r.get("model_version") != model_version:
                continue
            score = float(r.get("raw_score", 0))
            if score_min is not None and score < score_min:
                continue
            if score_max is not None and score > score_max:
                continue
            out.append(r)
        return out
