# BTCUSDT Stage 3：缠论多周期信号接入预演报告

## 阶段定位

Stage 3 的目标是把 Stage 2 的 `baseline_mtf_v0_1` 从“管道测试信号”升级为“缠论级别递归思想下的多周期信号适配器”。本阶段在当前会话里不能直接修改你的本地项目源码，因此我完成的是：

1. 基于你上传的 BTCUSDT 六周期历史数据，生成 `chanlun_mtf_adapter_v0_2` 离线预演样本池；
2. 输出可迁入项目的 `closed_kline`、`lifecycle`、`chanlun_signal_adapter`、`position_sizing` 模块；
3. 生成新的 SignalRecord 与 calibration summary；
4. 保留明确限制：本适配器是透明的缠论启发式桥接层，落地到本地项目时应接入已有 `ChanlunAnalyzer / MultiTimeframeAnalyzer` 的真实结果。

## 数据窗口

- 共同窗口：`2024-07-19T16:00:00+00:00` 到 `2026-07-08T12:00:00+00:00`
- 锚定周期：1h
- 标签窗口：12 根 1h K线，即约 12 小时
- 成本口径：10 bps
- 模型版本：`chanlun_mtf_adapter_v0_2`

## 样本池结果

- finalized SignalRecord：14,869 条
- overall win rate：46.37%
- overall avg_return：-0.0349%
- signal 分布：`{'long': 7621, 'short': 7248}`
- strength 分布：`{'strong': 8497, 'moderate': 3360, 'weak': 2458, 'conflicting': 554}`

## 当前 aligned endpoint 快照

> 注意：该快照对齐到所有周期共同 closed-only 终点，不等于最新实时市场。

- 时间：`2026-07-07T22:00:00+00:00`
- 价格：`63551.02`
- 信号：`short`
- raw_score：`62.5`
- strength：`moderate`
- lifecycle：`active`
- 各级别方向：`{'1d': 'neutral', '4h': 'long', '1h': 'short', '30m': 'short', '15m': 'short', '5m': 'short'}`

## 本阶段新增的关键机制

### 1. Closed-only K线过滤

实时分析必须先过滤未收盘 K线，否则 4h/1d 刚开盘的 K线会污染 MACD、分型、笔、线段、中枢和校准结果。

### 2. 信号生命周期

新增四类状态：

- `active`：信号仍有效；
- `downgraded`：原方向没有完全失效，但执行级别下降；
- `invalidated`：操作级别和触发级别反向确认；
- `observe`：多周期冲突，暂不执行。

### 3. 缠论级别递归权重

本阶段不是等权投票，而是按角色分层：

- 1d：background level；
- 4h / 1h：operation level；
- 30m / 15m / 5m：trigger level。

这避免把 5m 短线反弹误判成日线反转，也避免把日线压制误判成 5m 不能交易。

## 重要限制

`chanlun_mtf_adapter_v0_2` 仍是会话内生成的透明预演模型，不等价于你本地项目中真实的缠论算法。下一步需要在本地项目中把已有模块接进来：

- `src/core/chanlun/analyzer.py`
- `src/core/chanlun/multi_timeframe.py`
- `src/core/chanlun/dynamics.py`
- `src/core/chanlun/regime.py`

然后由真实缠论输出填充 `FeatureSnapshot`。

## 下一步 Stage 4

Stage 4 应进入“本地项目集成”：

1. 把 `src_core_signals/*` 迁入 `src/core/signals/`；
2. 在 `run_backtest.py` 或 `run_backtest_multi.py` 中调用 `ChanlunSignalAdapter.to_snapshot()`；
3. 每个真实缠论信号生成 `SignalRecord`；
4. 使用 `calibration.py` 查询相似历史样本；
5. 修改 `run_live_monitor.py`，实时输出 `raw_score` 与 `historical_win_rate`；
6. 样本不足时强制降级为 observe；
7. 对 strong short 做 `active / downgraded / invalidated / reactivated` 生命周期判断。


## 输出文件清单

- `data_feature_store/btcusdt_chanlun_mtf_signal_records_v0_2.jsonl`：Stage 3 SignalRecord 样本池。
- `data_feature_store/calibration_chanlun_mtf_by_bucket.csv`：按 direction / strength / score_bucket / regime 聚合的校准结果。
- `snapshots/latest_aligned_chanlun_mtf_snapshot.json`：共同 closed-only 终点的多周期信号快照。
- `src_core_signals/closed_kline.py`：未收盘 K线过滤。
- `src_core_signals/lifecycle.py`：信号生命周期判断。
- `src_core_signals/chanlun_signal_adapter.py`：真实缠论输出到 FeatureSnapshot 的适配器。
- `src_core_signals/position_sizing.py`：基于校准结果的保守仓位建议。
- `reports/CONTEXT_COMPRESSED_FOR_NEXT_STEP.md`：下一步上下文压缩。
