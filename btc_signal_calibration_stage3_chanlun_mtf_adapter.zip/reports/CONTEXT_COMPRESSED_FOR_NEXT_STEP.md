# 压缩上下文：BTCUSDT Signal Calibration Center Stage 3 完成状态

## 已完成
- Stage 1：六周期 BTCUSDT 数据底座验收通过。
- Stage 2：Feature Store MVP + baseline SignalRecord 管道跑通。
- Stage 3：生成 `chanlun_mtf_adapter_v0_2` 缠论多周期适配器预演样本池。

## Stage 3 核心输出
- 共同窗口：2024-07-19T16:00:00+00:00 到 2026-07-08T12:00:00+00:00
- 锚定周期：1h
- 标签窗口：12 bars / 约 12 小时
- finalized records：14,869
- overall win rate：46.37%
- 模型版本：chanlun_mtf_adapter_v0_2

## Stage 3 新增模块
- `closed_kline.py`：过滤未收盘 K线。
- `lifecycle.py`：active / downgraded / invalidated / observe。
- `chanlun_signal_adapter.py`：把真实 ChanlunAnalyzer/MultiTimeframeAnalyzer 输出转成 FeatureSnapshot。
- `position_sizing.py`：基于校准结果的保守仓位建议。

## 重要限制
当前 stage3 是缠论启发式适配预演，不是用户本地项目真实 ChanlunAnalyzer 的直接运行结果。下一步应在本地项目中把 `src_core_signals/*` 迁入 `src/core/signals/`，再把真实 analyzer 输出接入 `FeatureSnapshot`。

## 下一步
Stage 4：本地项目集成与真实信号回测注入。重点改造 `run_backtest.py / run_backtest_multi.py / run_live_monitor.py`。
